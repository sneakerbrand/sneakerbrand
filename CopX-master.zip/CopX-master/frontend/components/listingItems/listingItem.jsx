// import React from 'react';
// import { Link } from 'react-router-dom';

// export const ListingItem = () => {
//     return(
//         <div>
//             {/* <Link to={`/listingitems/${}`} /> */}
//             works
//         </div>
//     )
// }
