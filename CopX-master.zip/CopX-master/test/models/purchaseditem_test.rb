require 'test_helper'

class PurchaseditemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
