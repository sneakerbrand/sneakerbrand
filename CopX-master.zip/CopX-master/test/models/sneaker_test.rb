require 'test_helper'

class SneakerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
