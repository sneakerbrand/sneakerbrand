require 'test_helper'

class PurchasedItemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
